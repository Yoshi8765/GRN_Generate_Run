BioTapestry license is in LICENSE.txt; Copyright (c) 2003-2017 Institute for Systems Biology
LICENSE-SUN.txt is for some of the button images in BioTapestry.
launch4j-head-LICENSE.txt refers to the .exe wrapper code used to launch BioTapestry on Windows.
