import roadrunner
import tester

roadrunner.sigtrap()

tester.runTester()
